/* 
CVSU - Reymar Victoriano Mirante
Activity 04
This is a program to check if the triangle is Equilateral, Isoceles or SCalene. 
*/

// Ask the user what is the sides of triangle.
var a = prompt("Enter the length of side a");
var b = prompt("Enter the length of side b");
var c = prompt("Enter the length of side c");
      
// Function to check the type of triangle.
function determineTriangle(a, b, c) {
  if (a == b && b == c) {
    return "EQUILATERAL";
  }
  else if (a == b || b == c || c == a) {
      return "ISOSCELES";
  }
  else {
      return "SCALENE";
  }
}

 // Call the function and store the result in a variable.
let result = determineTriangle(a, b, c);
// Display the output in an alert box.
alert("The triangle is " + result + ".");